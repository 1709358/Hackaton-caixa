import requests
import googlemaps
from datetime import datetime

def calcularCoordenades(response):
    
    geometry = response['results'][0]['geometry']
    lat = geometry['location']['lat']
    lon = geometry['location']['lng']
    print(lat,lon)