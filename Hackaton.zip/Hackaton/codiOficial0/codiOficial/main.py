from functions import *
import pandas as pd
#______________________DECLARACION_KEY______________________________________
API_KEY = 'AIzaSyAHNyBEtAf3PBIXpFIhKWd_xGNulj1Wsdg'
base_url = 'https://maps.googleapis.com/maps/api/geocode/json?'
#______________________MIRAR_TABLA_EXCEL_____________________________________
municipis = pd.read_excel('Dades_Municipis.xlsx', index_col=0, header=11,usecols="Q",skiprows=[326]).index
codIne = pd.read_excel('Dades_Municipis.xlsx', index_col=0, header=11,usecols="P",skiprows=[326]).index
nomMunicipiGoogle = []
for i in zip(municipis,codIne):
    if(i[1]<10000):
        nomMunicipiGoogle.append(i[0] + "0" + str(i[1]))
    else:
        nomMunicipiGoogle.append(i[0] + str(i[1]))
positionMunicipi = list(range(len(nomMunicipiGoogle)))
#print(data_excel)
#______________________MIRAR_COORDENADAS_PUEBLOS_____________________________
kruskalMatrix= [list(range(len(nomMunicipiGoogle)))] * len(nomMunicipiGoogle) 
for municipiOrigin in zip(nomMunicipiGoogle,positionMunicipi):
    for municipiDesti in zip(nomMunicipiGoogle,positionMunicipi):
        now = datetime.now()
        gmaps_client = googlemaps.Client(key =API_KEY)
        print(municipiOrigin[0] + " " + municipiDesti[0] + " " + str(municipiDesti[1]))
        kruskalMatrix[municipiOrigin[1]][municipiDesti[1]] = gmaps_client.directions(municipiOrigin[0], municipiDesti[0], mode="driving", departure_time=now, transit_mode='van')[0]['legs'][0]['duration']['value']
print(kruskalMatrix)
