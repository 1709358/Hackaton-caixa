import sqlite3
import json

class BD:
   
    def __init__(self) -> None:
        pass




    def conexion(self):
        # Crear una conexión a la base de datos SQLite
        # Si la base de datos no existe, se creará automáticamente
        self.conn = sqlite3.connect('bsCaixaE.db')

        # Crear un objeto cursor
        self.cursor = self.conn.cursor()

    def crearRuta(self, nombreRuta):
        self.cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{nombreRuta}'")
        if self.cursor.fetchone():
            print(f"La tabla {nombreRuta} ya existe.")
        else:
            self.cursor.execute(f"""CREATE TABLE IF NOT EXISTS {nombreRuta} (
                    id INTEGER PRIMARY KEY, 
                    municipio TEXT,
                    codeINE INTEGER,
                    bloc INTEGER,
                    poblacion INTEGER,
                    estanciaMin INTEGER)""")
    
    def eliminarRuta(self, nombreRuta):
        # Verificar si la tabla existe
        self.cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{nombreRuta}'")
        if self.cursor.fetchone():
            # Si la tabla existe, eliminarla
            self.cursor.execute(f"DROP TABLE {nombreRuta}")
            print(f"La tabla {nombreRuta} ha sido eliminada.")
        else:
            print(f"La tabla {nombreRuta} no existe.")
        # Guardar los cambios
        self.conn.commit()

    def insertarNodo(self, ruta, id, municipio, codeINE, bloc, poblacion, estanciaMin):
        # Insertar datos en la tabla
        self.cursor.execute("INSERT INTO " + ruta + " VALUES (?, ?, ?, ?, ?, ?)", (id, municipio, codeINE, bloc, poblacion, estanciaMin))
        # Guardar los cambios
        self.conn.commit() 

    def eliminarNodo(self, ruta, id):
        # Verificar si la tabla existe
        self.cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{ruta}'")
        if self.cursor.fetchone():
            # Si la tabla existe, eliminar el nodo
            self.cursor.execute(f"DELETE FROM {ruta} WHERE id = ?", (id,))
            print(f"El nodo con id {id} ha sido eliminado de la tabla {ruta}.")
        else:
            print(f"La tabla {ruta} no existe.")
        # Guardar los cambios
        self.conn.commit()


    # Cerrar la conexión
    def cerrarConexion(self):
        self.conn.close()
    

    def extraer_numeros(ruta_archivo):
        numeros = []
        with open(ruta_archivo, 'r') as f:
            for linea in f:
                lista = json.loads(linea)
                numeros.append(lista)
        return numeros

    def crearFloyd(self, numeros, floydRuta):

        
        # Crear la tabla si no existe
        self.cursor.execute(f"CREATE TABLE IF NOT EXISTS {floydRuta} (ciudad1 INTEGER, ciudad2 INTEGER, distancia INTEGER)")

        # Insertar cada número en la tabla
        for i in range(len(numeros)):
            for j in range(len(numeros[i])):
                self.cursor.execute(f"INSERT INTO {floydRuta} VALUES ({i}, {j}, {numeros[i][j]})")

        self.cerrarConexion(self)
